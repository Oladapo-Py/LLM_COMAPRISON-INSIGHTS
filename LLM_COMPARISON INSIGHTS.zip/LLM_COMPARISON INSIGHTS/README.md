LLM-Comparison-Insights/
├── data/
│   └── llm_dataset.csv             # Your dataset
├── dashboard/
│   └── LLM_Comparison.pbix         # Your Power BI file
│   └── dashboard_screenshot.png    # (Optional) Dashboard image
├── README.md                       # The GitHub README file
